from django.urls import path
from . import views

app_name = "main"   

urlpatterns = [
    path("players", views.players, name="players"),
    path("teams", views.teams, name="teams")
]